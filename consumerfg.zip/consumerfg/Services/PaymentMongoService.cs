﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;
using PaymentFrontEndAPI.Models;

namespace PaymentFrontEndAPI.Services
{
    public class PaymentMongoService
    {
        private readonly IMongoCollection<MongoOrderRequest> _ordersCollection;
        public PaymentMongoService(IOptions<OrderStoreDatabaseSettings> orderStoreDatabaseSettings)
        {
            var mongoClient = new MongoClient(
            orderStoreDatabaseSettings.Value.ConnectionString);

            var mongoDatabase = mongoClient.GetDatabase(
                orderStoreDatabaseSettings.Value.DatabaseName);

            _ordersCollection = mongoDatabase.GetCollection<MongoOrderRequest>(
                orderStoreDatabaseSettings.Value.OrdersCollectionName);

        }
        public async Task<List<MongoOrderRequest>> GetAsync() =>
    await _ordersCollection.Find(_ => true).ToListAsync();
    }
}
