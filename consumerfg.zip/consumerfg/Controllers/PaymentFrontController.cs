﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PaymentFrontEndAPI.Models;
using PaymentFrontEndAPI.Services;

namespace PaymentFrontEndAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentFrontController : ControllerBase
    {
        private readonly PaymentMongoService _ordersService;

        public PaymentFrontController(PaymentMongoService ordersService)
        {
            this._ordersService = ordersService;
        }

        [HttpGet]
        public async Task<List<MongoOrderRequest>> Get()
        {
           return  await _ordersService.GetAsync();
        }

    }
}
