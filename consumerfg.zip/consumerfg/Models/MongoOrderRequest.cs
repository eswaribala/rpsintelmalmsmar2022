﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace PaymentFrontEndAPI.Models
{
    public enum OrderStatus
    {
        INPROGRESS, COMPLETED, DELAYED, CANCELLED
    }
    public class MongoOrderRequest
    {
        [BsonId]
        
        public long OrderId { get; set; }
        public long ProductId { get; set; }
        public long Quantity { get; set; }

        public long Cost { get; set; }

        public OrderStatus OrderStatus { get; set; }
    }
}
