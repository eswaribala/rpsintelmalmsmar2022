﻿namespace PaymentService.Models
{
    public enum OrderStatus
    {
        INPROGRESS, COMPLETED, DELAYED, CANCELLED
    }
    public class OrderRequest
    {
        public long OrderId { get; set; }
        public long ProductId { get; set; }
        public long Quantity { get; set; }

        public long Cost { get; set; }

        public OrderStatus OrderStatus { get; set; }
    }
}
